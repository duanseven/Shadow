
Shadow的前身是NSun （http://duanseven.cnblogs.com）

Shadow 是一个支持WCF以及Remoting的 ORM 框架，集成了面向对象查询以及远程对象传输的功能。

Shadow是一个融合了建立在 Remoting的动态代理机制 以及Castle的动态代理机制

Shadow是一个使用3级缓存架构

Shadow是一个查询性能高于EF

Shadow是一个简单易用的ORM框架
